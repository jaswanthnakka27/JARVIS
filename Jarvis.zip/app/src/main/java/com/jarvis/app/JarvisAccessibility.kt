package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibility? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) {
                if (cur.isClickable) {
                    cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
                cur = cur.parent
            }
        }
        return false
    }

    private fun walkClick(n: AccessibilityNodeInfo?, desc: String): Boolean {
        if (n == null) return false
        val cd = n.contentDescription?.toString()
        if (cd != null && cd.equals(desc, ignoreCase = true)) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) {
                if (cur.isClickable) {
                    cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
                cur = cur.parent
            }
        }
        for (i in 0 until n.childCount) if (walkClick(n.getChild(i), desc)) return true
        return false
    }

    fun clickDesc(desc: String): Boolean = walkClick(rootInActiveWindow, desc)

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val f = findEditable(n.getChild(i))
            if (f != null) return f
        }
        return null
    }

    fun typeAnywhere(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // dir = direction of content you want to reveal ("down" shows more below / next reel)
    fun swipe(dir: String) {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "down" -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.25f) }
            "up" -> { p.moveTo(w / 2, h * 0.25f); p.lineTo(w / 2, h * 0.75f) }
            "right" -> { p.moveTo(w * 0.85f, h / 2); p.lineTo(w * 0.15f, h / 2) }
            else -> { p.moveTo(w * 0.15f, h / 2); p.lineTo(w * 0.85f, h / 2) }
        }
        dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 260)).build(),
            null, null
        )
    }

    fun swipeUpUnlock() {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val p = Path()
        p.moveTo(w / 2, h * 0.92f)
        p.lineTo(w / 2, h * 0.2f)
        dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(),
            null, null
        )
    }

    fun tap(xp: Float, yp: Float, dbl: Boolean) {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val p = Path()
        p.moveTo(w * xp, h * yp)
        val b = GestureDescription.Builder()
        b.addStroke(GestureDescription.StrokeDescription(p, 0, 40))
        if (dbl) b.addStroke(GestureDescription.StrokeDescription(p, 140, 40))
        dispatchGesture(b.build(), null, null)
    }

    private fun walkTexts(n: AccessibilityNodeInfo?, out: LinkedHashSet<String>, depth: Int) {
        if (n == null || out.size > 60 || depth > 25) return
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (!t.isNullOrEmpty() && t.length < 60) out.add(t)
        for (i in 0 until n.childCount) walkTexts(n.getChild(i), out, depth + 1)
    }

    /** A short summary of what is on screen, so the AI can pick exact things to tap. */
    fun dumpScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val out = LinkedHashSet<String>()
        walkTexts(root, out, 0)
        return "App: " + root.packageName + ". Visible: " + out.joinToString(" | ")
    }
}
