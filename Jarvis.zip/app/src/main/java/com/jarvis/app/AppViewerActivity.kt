package com.jarvis.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebView
import java.io.File

/** Runs the apps Karen builds (single-file web apps) full screen, like a normal app. */
class AppViewerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val slug = (intent.getStringExtra("slug") ?: "").filter { it.isLetterOrDigit() || it == '-' }
        val f = File(File(filesDir, "apps"), "$slug.html")
        if (slug.isEmpty() || !f.exists()) { finish(); return }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = false
        wv.setBackgroundColor(Color.BLACK)
        wv.loadDataWithBaseURL("https://karen.local/", f.readText(), "text/html", "utf-8", null)
        setContentView(wv)
    }
}
