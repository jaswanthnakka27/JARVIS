package com.jarvis.app

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the small free offline English model (about 40 MB) the first time only. */
object WakeModel {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    fun dir(ctx: Context) = File(ctx.filesDir, "vosk-model")
    fun ready(ctx: Context) = File(dir(ctx), ".ready").exists()

    fun download(ctx: Context) {
        val out = dir(ctx)
        out.deleteRecursively()
        out.mkdirs()
        val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        ZipInputStream(conn.inputStream.buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val name = e.name.substringAfter('/', "")   // drop the top folder name
                if (name.isNotEmpty()) {
                    val f = File(out, name)
                    if (!f.canonicalPath.startsWith(out.canonicalPath)) throw SecurityException("bad zip")
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { zin.copyTo(it) }
                    }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
        File(out, ".ready").writeText("ok")
    }
}
