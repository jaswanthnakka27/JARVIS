package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.telephony.TelephonyManager
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.RecognitionListener as VoskListener

class JarvisService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var state = ""
        @Volatile var mode = 0            // 0 idle, 1 listening, 2 thinking, 3 speaking
        @Volatile var onState: (() -> Unit)? = null
        @Volatile var onHide: (() -> Unit)? = null
        const val ACTION_TALK = "com.jarvis.app.TALK"
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var wakeRec: Recognizer? = null
    private var callRec: Recognizer? = null
    private var speech: SpeechService? = null
    @Volatile private var wakeActive = false
    @Volatile private var ringing = false
    @Volatile private var callActive = false
    private var recognizer: SpeechRecognizer? = null
    private lateinit var voice: Voice
    private var stopped = false
    private var awaitingCommand = false
    private var screenCtx = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TALK) main.post { triggerTalk() }
        return START_STICKY
    }

    private fun setState(m: Int, s: String) {
        mode = m
        state = s
        main.post { onState?.invoke() }
    }

    private fun toast(t: String) { main.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() } }

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("karen", "Karen", NotificationManager.IMPORTANCE_LOW))
        val talk = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction(ACTION_TALK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Talk", talk
        ).build()
        val n = Notification.Builder(this, "karen")
            .setContentTitle("Karen is online")
            .setContentText("Say \"Karen\" or tap Talk")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(action)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        voice = Voice(this) { afterSpeak() }
        ContextCompat.registerReceiver(
            this, phoneReceiver, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
            ContextCompat.RECEIVER_EXPORTED
        )
        loadModelThenWake()
    }

    // ---------- phone calls: say "answer" or "reject" while it rings ----------
    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_RINGING -> main.post {
                    ringing = true; callActive = false
                    stopWake(); startWake()
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> main.post {
                    ringing = false; callActive = true
                    stopWake()
                    setState(0, "On a call")
                }
                TelephonyManager.EXTRA_STATE_IDLE -> main.post {
                    ringing = false; callActive = false
                    stopWake(); startWake()
                }
            }
        }
    }

    // ---------- Wake word: free, offline, silent (no beeps) ----------
    private fun loadModelThenWake() {
        setState(0, "Getting ready. The first time this downloads about 40 MB, keep Wi-Fi on...")
        Thread {
            try {
                if (!WakeModel.ready(this)) WakeModel.download(this)
                val m = Model(WakeModel.dir(this).absolutePath)
                val w = Recognizer(m, 16000f, "[\"karen\", \"jarvis\", \"[unk]\"]")
                val cr = Recognizer(m, 16000f, "[\"answer\", \"accept\", \"pick up\", \"reject\", \"decline\", \"hang up\", \"[unk]\"]")
                main.post { model = m; wakeRec = w; callRec = cr; startWake() }
            } catch (e: Exception) {
                WakeModel.dir(this).deleteRecursively()
                toast("Wake word not available: " + e.message + ". You can still use the Talk button.")
                setState(0, "Wake word not available. Tap the reactor to talk.")
            }
        }.start()
    }

    private fun startWake() {
        main.post {
            if (stopped || wakeActive || callActive) return@post
            if (model == null) return@post
            try {
                val r = (if (ringing) callRec else wakeRec) ?: return@post
                r.reset()
                val s = SpeechService(r, 16000f)
                s.startListening(wakeListener)
                speech = s
                wakeActive = true
                setState(0, if (ringing) "INCOMING CALL. Say ANSWER or REJECT" else "ONLINE. Say \"Karen\"")
            } catch (e: Exception) {
                toast("Wake word error: " + e.message)
            }
        }
    }

    private fun stopWake() {
        wakeActive = false
        try { speech?.stop(); speech?.shutdown() } catch (e: Exception) {}
        speech = null
    }

    private val wakeListener = object : VoskListener {
        private fun check(h: String?) {
            if (!wakeActive || h == null) return
            val t = h.lowercase()
            if (ringing) {
                if (t.contains("answer") || t.contains("accept") || t.contains("pick up")) {
                    main.post { if (wakeActive) { stopWake(); runCallAction("answer_call") } }
                } else if (t.contains("reject") || t.contains("decline") || t.contains("hang up")) {
                    main.post { if (wakeActive) { stopWake(); runCallAction("end_call") } }
                }
            } else if (t.contains("karen") || t.contains("jarvis")) {
                main.post { if (wakeActive) triggerTalk() }
            }
        }
        override fun onPartialResult(hypothesis: String?) = check(hypothesis)
        override fun onResult(hypothesis: String?) = check(hypothesis)
        override fun onFinalResult(hypothesis: String?) {}
        override fun onTimeout() {}
        override fun onError(exception: Exception?) {
            main.post { stopWake(); main.postDelayed({ startWake() }, 1500) }
        }
    }

    private fun runCallAction(name: String) {
        Thread {
            Actions.run(this, JSONArray().put(JSONObject().put("action", name)))
        }.start()
    }

    // ---------- Karen woke up: show the HUD, then listen for the command ----------
    private fun triggerTalk() {
        if (stopped || callActive) return
        stopWake()
        voice.stop()
        screenCtx = JarvisAccessibility.instance?.dumpScreen() ?: ""   // what you were looking at
        Actions.wake(this)
        awaitingCommand = true
        openUi()
        setState(1, "LISTENING... speak now")
        main.postDelayed({ listen() }, 600)
    }

    private fun openUi() {
        val i = Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        val ctx: Context = JarvisAccessibility.instance ?: this
        try { ctx.startActivity(i) } catch (e: Exception) {}
    }

    private fun listen() {
        main.post {
            if (stopped) return@post
            setState(1, "LISTENING... speak now")
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            recognizer?.startListening(i)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onError(error: Int) {
            awaitingCommand = false
            Actions.pendingContact = null
            setState(0, "I didn't hear anything.")
            main.post { startWake() }
        }

        override fun onResults(r: Bundle?) {
            val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            awaitingCommand = false
            if (text.isBlank()) { Actions.pendingContact = null; startWake(); return }
            process(text)
        }
    }

    // ---------- understand and do ----------
    private fun process(cmd: String) {
        setState(2, "YOU: $cmd\nTHINKING...")
        val screen = screenCtx
        Thread {
            var reply: String
            try {
                val pending = Actions.pendingContact
                val actions: JSONArray
                if (pending != null) {
                    Actions.pendingContact = null
                    val c = cmd.lowercase().trim()
                    actions = if (c == "cancel" || c == "never mind" || c == "nevermind" || c == "stop")
                        Brain.say("Okay, cancelled.")
                    else JSONArray().put(
                        JSONObject().put("action", "whatsapp").put("contact", pending).put("text", cmd)
                    )
                } else {
                    actions = Brain.ask(this, cmd, screen)
                }
                reply = runActions(actions)
            } catch (e: Exception) {
                reply = "Something went wrong."
            }
            main.post {
                if (reply.isBlank()) setState(0, "Done. Say \"Karen\"")
                if (reply.isBlank()) startWake() else speak(reply)
            }
        }.start()
    }

    private fun runActions(actions: JSONArray): String {
        if (Actions.needsScreen(actions)) {
            if (Actions.lockedBlocks(this, actions))
                return "Your phone is locked. Unlock it first, or ask for something that works while locked."
            main.post { onHide?.invoke() }       // get the HUD out of the way so I can control the app behind it
            Thread.sleep(700)
        }
        return Actions.run(this, actions)
    }

    private fun speak(text: String) {
        setState(3, "KAREN: $text")
        voice.speak(text)
    }

    private fun afterSpeak() {
        if (awaitingCommand || Actions.pendingContact != null) {
            awaitingCommand = true
            listen()
        } else {
            setState(0, "ONLINE. Say \"Karen\"")
            startWake()
        }
    }

    override fun onDestroy() {
        stopped = true
        running = false
        try { unregisterReceiver(phoneReceiver) } catch (e: Exception) {}
        stopWake()
        try { wakeRec?.close(); callRec?.close(); model?.close() } catch (e: Exception) {}
        recognizer?.destroy()
        voice.shutdown()
        state = "OFFLINE"
        mode = 0
        super.onDestroy()
    }
}
