package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.core.app.ServiceCompat
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.util.Locale
import org.vosk.android.RecognitionListener as VoskListener

class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile var running = false
        @Volatile var state = ""
        @Volatile var onState: (() -> Unit)? = null
        const val ACTION_TALK = "com.jarvis.app.TALK"
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var rec: Recognizer? = null
    private var speech: SpeechService? = null
    @Volatile private var wakeActive = false
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var stopped = false
    private var awaitingCommand = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TALK) main.post { triggerTalk() }
        return START_STICKY
    }

    private fun setState(s: String) {
        state = s
        main.post { onState?.invoke() }
    }

    private fun toast(t: String) = main.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val talk = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction(ACTION_TALK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Talk", talk
        ).build()
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is ready")
            .setContentText("Say \"Jarvis\" or tap Talk")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(action)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
        loadModelThenWake()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        tts?.language = Locale.getDefault()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { afterSpeak() } }
            override fun onError(id: String?) { main.post { afterSpeak() } }
        })
    }

    private fun afterSpeak() {
        if (awaitingCommand) listen() else startWake()
    }

    private fun speak(text: String) {
        setState("Jarvis: $text")
        if (!ttsReady) { afterSpeak(); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // ---------- Wake word: free, offline, silent (no beeps) ----------
    private fun loadModelThenWake() {
        setState("Getting ready (the first time this downloads about 40 MB, keep Wi-Fi on)...")
        Thread {
            try {
                if (!WakeModel.ready(this)) WakeModel.download(this)
                val m = Model(WakeModel.dir(this).absolutePath)
                main.post { model = m; startWake() }
            } catch (e: Exception) {
                WakeModel.dir(this).deleteRecursively()
                toast("Wake word not available: " + e.message + ". You can still use the Talk button.")
                setState("Wake word not available. Tap Talk to give a command.")
            }
        }.start()
    }

    private fun startWake() {
        main.post {
            if (stopped || wakeActive) return@post
            val m = model ?: return@post
            try {
                if (rec == null) rec = Recognizer(m, 16000f, "[\"jarvis\", \"[unk]\"]")
                rec?.reset()
                val s = SpeechService(rec, 16000f)
                s.startListening(wakeListener)
                speech = s
                wakeActive = true
                setState("Say \"Jarvis\"...")
            } catch (e: Exception) {
                toast("Wake word error: " + e.message)
            }
        }
    }

    private fun stopWake() {
        wakeActive = false
        try { speech?.stop(); speech?.shutdown() } catch (e: Exception) {}
        speech = null
    }

    private val wakeListener = object : VoskListener {
        private fun check(h: String?) {
            if (wakeActive && h != null && h.contains("jarvis", ignoreCase = true)) {
                main.post { if (wakeActive) triggerTalk() }
            }
        }
        override fun onPartialResult(hypothesis: String?) = check(hypothesis)
        override fun onResult(hypothesis: String?) = check(hypothesis)
        override fun onFinalResult(hypothesis: String?) {}
        override fun onTimeout() {}
        override fun onError(exception: Exception?) {
            main.post { stopWake(); main.postDelayed({ startWake() }, 1500) }
        }
    }

    // ---------- Jarvis woke up: show the app, then listen for the command ----------
    private fun triggerTalk() {
        if (stopped) return
        stopWake()
        tts?.stop()
        awaitingCommand = true
        openUi()
        setState("Listening... say your command")
        main.postDelayed({ listen() }, 500)
    }

    private fun openUi() {
        val i = Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        val ctx: Context = JarvisAccessibility.instance ?: this
        try { ctx.startActivity(i) } catch (e: Exception) {}
    }

    private fun listen() {
        main.post {
            if (stopped) return@post
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            recognizer?.startListening(i)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onError(error: Int) {
            awaitingCommand = false
            setState("I didn't hear anything.")
            main.post { startWake() }
        }

        override fun onResults(r: Bundle?) {
            val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            awaitingCommand = false
            if (text.isBlank()) { startWake(); return }
            setState("You: $text")
            process(text)
        }
    }

    private fun process(cmd: String) {
        Thread {
            val reply = try {
                Actions.run(this, Brain.ask(this, cmd))
            } catch (e: Exception) {
                "Something went wrong. Check your internet and API key."
            }
            main.post { if (reply.isBlank()) startWake() else speak(reply) }
        }.start()
    }

    override fun onDestroy() {
        stopped = true
        running = false
        stopWake()
        try { rec?.close(); model?.close() } catch (e: Exception) {}
        recognizer?.destroy()
        tts?.shutdown()
        state = "Jarvis is stopped."
        super.onDestroy()
    }
}
