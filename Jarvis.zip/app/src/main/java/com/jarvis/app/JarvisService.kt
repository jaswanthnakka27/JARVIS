package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.TelephonyManager
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.util.concurrent.CopyOnWriteArrayList
import org.vosk.android.RecognitionListener as VoskListener

class JarvisService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var state = ""
        @Volatile var mode = 0            // 0 idle, 1 listening, 2 thinking, 3 speaking
        @Volatile var onState: (() -> Unit)? = null
        val log = CopyOnWriteArrayList<String>()
        const val ACTION_TALK = "com.jarvis.app.TALK"
        const val ACTION_CMD = "com.jarvis.app.CMD"

        fun addLog(s: String) {
            log.add(s)
            while (log.size > 30) log.removeAt(0)
        }

        private val NOISE = setOf("the", "a", "uh", "huh", "um", "hmm", "oh", "ah", "mm")
        private val END_PHRASES = setOf(
            "thanks", "thank you", "that's all", "thats all", "stop listening", "go to sleep",
            "bye", "goodbye", "never mind", "nevermind"
        )
        private const val IDLE_MS = 25000L
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var wakeRec: Recognizer? = null
    private var callRec: Recognizer? = null
    private var freeRec: Recognizer? = null
    private var speech: SpeechService? = null
    @Volatile private var wakeActive = false
    @Volatile private var sessionActive = false
    @Volatile private var ringing = false
    @Volatile private var callActive = false
    private var endAfterSpeak = false
    private var lastPartial = 0L
    private var stopped = false
    private lateinit var voice: Voice
    private val overlay by lazy { OverlayHud(this) }
    private val idleRunnable = Runnable { if (sessionActive) endSession() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TALK -> main.post { startSession(true, true) }
            ACTION_CMD -> {
                val c = intent?.getStringExtra("cmd") ?: ""
                if (c.isNotBlank()) main.post { startSession(false, false); handleCommand(c) }
            }
        }
        return START_STICKY
    }

    private fun setState(m: Int, s: String) {
        mode = m
        state = s
        main.post {
            if (sessionActive) overlay.update(m, s)
            onState?.invoke()
        }
    }

    private fun toast(t: String) { main.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() } }

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("karen", "Karen", NotificationManager.IMPORTANCE_LOW))
        val talk = PendingIntent.getService(
            this, 0, Intent(this, JarvisService::class.java).setAction(ACTION_TALK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Talk", talk
        ).build()
        val n = Notification.Builder(this, "karen")
            .setContentTitle("Karen is online")
            .setContentText("Say \"Karen\" or tap Talk")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(action)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        voice = Voice(this) { afterSpeak() }
        Actions.progress = { s -> setState(2, s) }
        ContextCompat.registerReceiver(
            this, phoneReceiver, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
            ContextCompat.RECEIVER_EXPORTED
        )
        Thread { Actions.warmApps(this) }.start()
        loadModelThenWake()
    }

    // ---------- phone calls: say "answer" or "reject" while it rings ----------
    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_RINGING -> main.post {
                    dropSession()
                    ringing = true; callActive = false
                    stopWake(); startWake()
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> main.post {
                    dropSession()
                    ringing = false; callActive = true
                    stopWake()
                    setState(0, "On a call")
                }
                TelephonyManager.EXTRA_STATE_IDLE -> main.post {
                    ringing = false; callActive = false
                    stopWake(); startWake()
                }
            }
        }
    }

    // ---------- offline engine (free, silent, no beeps) ----------
    private fun loadModelThenWake() {
        setState(0, "Getting ready. The first time this downloads about 40 MB, keep Wi-Fi on...")
        Thread {
            try {
                if (!WakeModel.ready(this)) WakeModel.download(this)
                val m = Model(WakeModel.dir(this).absolutePath)
                val w = Recognizer(m, 16000f, "[\"karen\", \"jarvis\", \"[unk]\"]")
                val cr = Recognizer(m, 16000f, "[\"answer\", \"accept\", \"pick up\", \"reject\", \"decline\", \"hang up\", \"[unk]\"]")
                val fr = Recognizer(m, 16000f)
                main.post {
                    model = m; wakeRec = w; callRec = cr; freeRec = fr
                    voice.prewarm(listOf("Yes, tell me.", "Okay, I'm here if you need me.", "Okay.", "Done."))
                    startWake()
                }
            } catch (e: Exception) {
                WakeModel.dir(this).deleteRecursively()
                toast("Wake word not available: " + e.message + ". You can still tap Talk.")
                setState(0, "Wake word not available. Tap the reactor to talk.")
            }
        }.start()
    }

    private fun releaseSpeech() {
        try { speech?.stop(); speech?.shutdown() } catch (e: Exception) {}
        speech = null
    }

    private fun startWake() {
        main.post {
            if (stopped || wakeActive || callActive || sessionActive) return@post
            if (model == null) return@post
            try {
                val r = (if (ringing) callRec else wakeRec) ?: return@post
                r.reset()
                val s = SpeechService(r, 16000f)
                s.startListening(wakeListener)
                speech = s
                wakeActive = true
                setState(0, if (ringing) "INCOMING CALL. Say ANSWER or REJECT" else "ONLINE. Say \"Karen\"")
            } catch (e: Exception) {
                toast("Wake word error: " + e.message)
            }
        }
    }

    private fun stopWake() {
        if (!wakeActive) return
        wakeActive = false
        releaseSpeech()
    }

    private val wakeListener = object : VoskListener {
        private fun check(h: String?) {
            if (!wakeActive || h == null) return
            val t = h.lowercase()
            if (ringing) {
                if (t.contains("answer") || t.contains("accept") || t.contains("pick up")) {
                    main.post { if (wakeActive) { stopWake(); runCallAction("answer_call") } }
                } else if (t.contains("reject") || t.contains("decline") || t.contains("hang up")) {
                    main.post { if (wakeActive) { stopWake(); runCallAction("end_call") } }
                }
            } else if (t.contains("karen") || t.contains("jarvis")) {
                main.post { if (wakeActive) startSession(true, true) }
            }
        }
        override fun onPartialResult(hypothesis: String?) = check(hypothesis)
        override fun onResult(hypothesis: String?) = check(hypothesis)
        override fun onFinalResult(hypothesis: String?) {}
        override fun onTimeout() {}
        override fun onError(exception: Exception?) {
            main.post { stopWake(); main.postDelayed({ startWake() }, 1500) }
        }
    }

    private fun runCallAction(name: String) {
        Thread { Actions.run(this, JSONArray().put(JSONObject().put("action", name))) }.start()
    }

    // ---------- a conversation: say "Karen" once, then keep giving orders ----------
    private fun startSession(greet: Boolean, listenNow: Boolean) {
        if (stopped || callActive) return
        stopWake()
        voice.stop()
        if (!sessionActive) {
            releaseSpeech()
            sessionActive = true
            overlay.show()
            Actions.wake(this)
        } else {
            pauseSession()
        }
        if (greet) speak("Yes, tell me.") else if (listenNow) listenSession()
    }

    private fun listenSession() {
        if (!sessionActive || stopped) return
        try {
            val cur = speech
            if (cur == null) {
                val r = freeRec ?: return
                r.reset()
                val s = SpeechService(r, 16000f)
                s.startListening(sessionListener)
                speech = s
            } else {
                cur.setPause(false)
            }
            setState(1, "LISTENING... give your order")
            armIdle()
        } catch (e: Exception) {
            toast("Mic error: " + e.message)
            endSession()
        }
    }

    private fun pauseSession() {
        main.removeCallbacks(idleRunnable)
        try { speech?.setPause(true) } catch (e: Exception) {}
    }

    private fun armIdle() {
        main.removeCallbacks(idleRunnable)
        main.postDelayed(idleRunnable, IDLE_MS)
    }

    private fun dropSession() {
        main.removeCallbacks(idleRunnable)
        if (sessionActive) {
            sessionActive = false
            releaseSpeech()
            overlay.hide()
        }
    }

    private fun endSession() {
        Actions.pendingContact = null
        dropSession()
        setState(0, "ONLINE. Say \"Karen\"")
        startWake()
    }

    private val sessionListener = object : VoskListener {
        override fun onPartialResult(hypothesis: String?) {
            val t = try { JSONObject(hypothesis ?: "{}").optString("partial") } catch (e: Exception) { "" }
            if (t.isNotBlank()) main.post {
                if (sessionActive) {
                    armIdle()
                    val now = System.currentTimeMillis()
                    if (now - lastPartial > 250) { lastPartial = now; setState(1, "HEARING: $t") }
                }
            }
        }
        override fun onResult(hypothesis: String?) {
            val t = try { JSONObject(hypothesis ?: "{}").optString("text") } catch (e: Exception) { "" }
            if (t.isNotBlank()) main.post { if (sessionActive) handleCommand(t) }
        }
        override fun onFinalResult(hypothesis: String?) {}
        override fun onTimeout() {}
        override fun onError(exception: Exception?) {
            main.post {
                if (sessionActive) { releaseSpeech(); main.postDelayed({ listenSession() }, 800) }
            }
        }
    }

    private fun handleCommand(raw: String) {
        var text = raw.trim()
        val low = text.lowercase()
        for (w in listOf("karen", "jarvis")) {
            if (low.startsWith(w)) { text = text.substring(w.length).trim(' ', ',', '.'); break }
        }
        val l = text.lowercase()
        if (l.length < 2 || l in NOISE) return
        pauseSession()
        if (l in END_PHRASES) {
            endAfterSpeak = true
            speak("Okay, I'm here if you need me.")
            return
        }
        addLog("\u25B8 $text")
        process(text)
    }

    // ---------- understand and do ----------
    private fun process(cmd: String) {
        setState(2, "YOU: $cmd\nTHINKING...")
        Thread {
            val reply = StringBuilder()
            try {
                val pending = Actions.pendingContact
                if (pending != null) {
                    Actions.pendingContact = null
                    val c = cmd.lowercase().trim()
                    if (c == "cancel" || c == "never mind" || c == "nevermind" || c == "stop") {
                        reply.append("Okay, cancelled.")
                    } else {
                        reply.append(runActions(JSONArray().put(
                            JSONObject().put("action", "whatsapp").put("contact", pending).put("text", cmd)
                        )))
                    }
                } else {
                    val quick = Brain.localCommand(this, cmd)
                    if (quick != null) {
                        reply.append(runActions(quick))
                    } else {
                        var steps = 0
                        var more = true
                        while (more && steps < 5 && !stopped) {
                            val screen = JarvisAccessibility.instance?.dumpScreen() ?: ""
                            val plan = Brain.plan(this, cmd, screen, steps > 0)
                            reply.append(runActions(plan.actions)).append(' ')
                            more = plan.more && Actions.hasDoing(plan.actions)
                            steps++
                            if (more) Thread.sleep(1200)
                        }
                    }
                }
            } catch (e: Exception) {
                reply.append("Something went wrong.")
            }
            val out = reply.toString().trim()
            main.post {
                addLog("\u25C2 " + (if (out.isBlank()) "done" else out))
                if (out.isBlank()) afterSpeak() else speak(out)
            }
        }.start()
    }

    private fun runActions(actions: JSONArray): String {
        if (Actions.lockedBlocks(this, actions))
            return "Your phone is locked. Unlock it first, or ask for something that works while locked."
        return Actions.run(this, actions)
    }

    private fun speak(text: String) {
        setState(3, "KAREN: $text")
        voice.speak(text)
    }

    private fun afterSpeak() {
        if (endAfterSpeak) { endAfterSpeak = false; endSession(); return }
        if (sessionActive) { listenSession(); return }
        setState(0, "ONLINE. Say \"Karen\"")
        startWake()
    }

    override fun onDestroy() {
        stopped = true
        running = false
        main.removeCallbacks(idleRunnable)
        try { unregisterReceiver(phoneReceiver) } catch (e: Exception) {}
        releaseSpeech()
        overlay.hide()
        try { wakeRec?.close(); callRec?.close(); freeRec?.close(); model?.close() } catch (e: Exception) {}
        voice.shutdown()
        Actions.progress = null
        state = "OFFLINE"
        mode = 0
        super.onDestroy()
    }
}
