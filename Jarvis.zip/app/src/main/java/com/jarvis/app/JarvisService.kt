package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.ServiceCompat
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile var running = false
        // Add spellings your phone's speech engine hears for "Jarvis"
        val WAKE_WORDS = listOf("jarvis", "jarvish", "jaarvis", "जार्विस", "जारविस")
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var stopped = false
    private var awaitingCommand = false

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" and then your command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
        listen()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        tts?.language = Locale.getDefault()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { listen() } }
            override fun onError(id: String?) { main.post { listen() } }
        })
    }

    private fun speak(text: String) {
        if (!ttsReady) { listen(); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun listen() {
        main.post {
            if (stopped) return@post
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            recognizer?.startListening(i)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
            awaitingCommand = false
            val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 300L
            main.postDelayed({ listen() }, delay)
        }

        override fun onResults(r: Bundle?) {
            val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            handle(text)
        }
    }

    private fun handle(text: String) {
        if (text.isBlank()) { listen(); return }
        if (awaitingCommand) { awaitingCommand = false; process(text); return }

        val lower = text.lowercase()
        val word = WAKE_WORDS.firstOrNull { lower.contains(it) }
        if (word == null) { listen(); return }

        val rest = text.substring(lower.indexOf(word) + word.length).trim(' ', ',', '.', '!', '?')
        if (rest.isEmpty()) { awaitingCommand = true; speak("Yes?") } else process(rest)
    }

    private fun process(cmd: String) {
        Thread {
            val reply = try {
                Actions.run(this, Brain.ask(this, cmd))
            } catch (e: Exception) {
                "Something went wrong. Check your internet and API key."
            }
            main.post { if (reply.isBlank()) listen() else speak(reply) }
        }.start()
    }

    override fun onDestroy() {
        stopped = true
        running = false
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
