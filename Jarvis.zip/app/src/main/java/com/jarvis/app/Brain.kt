package com.jarvis.app

import android.content.Context
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Plan(val actions: JSONArray, val more: Boolean)

object Brain {
    private val history = ArrayList<Pair<String, String>>()
    private val FALLBACKS = listOf("gemini-3.7-flash", "gemini-3.5-flash")

    private const val SYSTEM = """You are Karen, a witty, warm, confident AI assistant that controls an Android phone, like the helpful suit AI from the Spider-Man movies. Keep spoken replies short, one or two sentences. Call the user boss now and then.
The user speaks a command. Reply with ONLY a JSON object: {"actions":[...],"more":false}
Set "more" to true only if you must SEE the screen after these actions to finish the task (for example you opened an app and still need to tap things inside it). You then get the new screen and can continue, up to 5 steps.
Actions:
{"action":"speak","text":"..."}
{"action":"open_app","target":"app name"}
{"action":"search","query":"..."}
{"action":"open_url","url":"https://..."}
{"action":"youtube","query":"..."}
{"action":"navigate","destination":"..."}
{"action":"call","target":"contact name or phone number"}
{"action":"whatsapp","contact":"name","text":"message"}  text may be empty, then Karen opens the chat and asks the user what to say
{"action":"instagram","section":"dms|reels|search|home"}
{"action":"global","which":"home|back|recents|notifications|quick_settings|lock|screenshot"}
{"action":"click","text":"exact visible text or label to tap"}
{"action":"type","text":"text to type into the text box"}
{"action":"scroll","dir":"up|down|left|right"}  down = reveal content below or next reel
{"action":"tap","x":0.5,"y":0.5}  screen position as fractions
{"action":"double_tap"}  likes a post or reel
{"action":"flashlight","on":true}
{"action":"volume","dir":"up|down|mute|unmute","steps":2}
{"action":"alarm","hour":7,"minute":30}
{"action":"timer","seconds":300}
{"action":"settings","which":"wifi|bluetooth|display|sound|battery|airplane|location|main"}
{"action":"answer_call"}
{"action":"end_call"}
{"action":"wake_screen"}
{"action":"unlock_swipe"}
{"action":"code","name":"short-name","language":"python|javascript|kotlin|java|c++|html","description":"what the program should do"}  writes real code and saves it in Downloads
{"action":"build_app","name":"App Name","description":"what the app should do"}  builds a working app that opens at once and can be added to the home screen
{"action":"wait","ms":1500}  use after open_app before click or type
The user message starts with context: time, battery, and what is visible on screen right now. Use the exact visible text for click. For questions or chat, just use speak with the answer. When asked to build or create an app, use build_app. When asked for code or a script or a program, use code. For phone tasks, finish with a short speak confirmation only if it adds value. Never invent actions. Output valid JSON only."""

    fun say(t: String): JSONArray =
        JSONArray().put(JSONObject().put("action", "speak").put("text", t))

    private fun act(vararg kv: Pair<String, Any>): JSONObject {
        val o = JSONObject()
        for ((k, v) in kv) o.put(k, v)
        return o
    }

    private fun msg(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun section(s: String): String = when {
        s.startsWith("dm") || s.contains("message") || s.contains("inbox") -> "dms"
        s.startsWith("reel") -> "reels"
        s.startsWith("search") || s.startsWith("explore") -> "search"
        else -> "home"
    }

    private fun battery(ctx: Context): Int = try {
        (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    } catch (e: Exception) { -1 }

    /** Simple commands run instantly on the phone, with no internet or AI needed. */
    fun localCommand(ctx: Context, cmd: String): JSONArray? {
        val c = cmd.lowercase().trim().trimEnd('.', '!', '?', ',').replace(" dot ", ".")
        fun one(vararg kv: Pair<String, Any>) = JSONArray().put(act(*kv))

        if (c in setOf("hello", "hi", "hey", "hello karen", "hi karen", "hey karen")) return say("Hello boss. Ready when you are.")
        if (c.contains("what time") || c == "time" || c.contains("what's the time"))
            return say("It's " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + ".")
        if (c.contains("what day") || c.contains("the date") || c == "date")
            return say("Today is " + SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()) + ".")
        if (c.contains("battery")) return say("Your battery is at " + battery(ctx) + " percent.")

        if (c in setOf("answer", "answer it", "answer the call", "answer call", "pick up", "pick it up", "accept", "accept the call"))
            return one("action" to "answer_call")
        if (c in setOf("reject", "decline", "hang up", "end call", "end the call", "cut the call", "reject the call", "decline the call"))
            return one("action" to "end_call")
        if (c == "unlock" || c == "unlock the phone" || c == "unlock my phone" || c == "wake up the screen")
            return JSONArray().put(act("action" to "wake_screen")).put(act("action" to "wait", "ms" to 700))
                .put(act("action" to "unlock_swipe"))

        Regex("^(?:send (?:a )?)?(?:whatsapp|message|text)(?: message)? (?:to )?(.+?) (?:saying|say|that says|that|and say|and tell (?:him|her|them)) (.+)$").find(c)?.let {
            return one("action" to "whatsapp", "contact" to it.groupValues[1], "text" to it.groupValues[2])
        }
        Regex("^(?:open|show) (.+?)(?:'s|s)? chat(?: on whatsapp)?$").find(c)?.let {
            return one("action" to "whatsapp", "contact" to it.groupValues[1], "text" to "")
        }
        Regex("^(?:send (?:a )?)?(?:whatsapp|message|text) (?:to )?([a-z ]{2,30})$").find(c)?.let {
            if (it.groupValues[1].trim().split(" ").size <= 3)
                return one("action" to "whatsapp", "contact" to it.groupValues[1].trim(), "text" to "")
        }

        Regex("^(?:open |go to |show )?instagram ?(dms?|direct messages|messages?|inbox|reels?|search|explore|home)?$").find(c)?.let {
            val s = it.groupValues[1]
            if (s.isNotEmpty()) return one("action" to "instagram", "section" to section(s))
        }
        Regex("^(?:open |show )?(dms?|messages|reels?) (?:on|in) instagram$").find(c)?.let {
            return one("action" to "instagram", "section" to section(it.groupValues[1]))
        }

        Regex("^(?:open|go to|visit|launch) (?:the )?(?:website |site )?((?:[a-z0-9-]+\\.)+[a-z]{2,}(?:/\\S*)?)$").find(c)?.let {
            return one("action" to "open_url", "url" to "https://" + it.groupValues[1])
        }
        Regex("^(?:open|go to|visit) (?:the )?(?:website|site) (.+)$").find(c)?.let {
            val n = it.groupValues[1].replace(" ", "")
            return one("action" to "open_url", "url" to "https://www." + (if (n.contains(".")) n else "$n.com"))
        }
        Regex("^(?:search|find|look up)(?: for)? (.+?) on youtube$").find(c)?.let {
            return one("action" to "youtube", "query" to it.groupValues[1])
        }
        Regex("^play (.+?)(?: on youtube)?$").find(c)?.let {
            return one("action" to "youtube", "query" to it.groupValues[1])
        }
        Regex("^(?:search|google|look up)(?: for)? (.+)$").find(c)?.let {
            return one("action" to "search", "query" to it.groupValues[1])
        }

        Regex("^(?:please )?(?:open|launch|start) (?:the )?(.+?)(?: app)?$").find(c)?.let {
            val target = it.groupValues[1]
            if (!target.contains(" and ") && !target.contains(" then "))
                return one("action" to "open_app", "target" to target)
        }
        Regex("^(?:please )?(?:call|dial|phone) (.+)$").find(c)?.let {
            return one("action" to "call", "target" to it.groupValues[1])
        }
        if (c.contains("flashlight") || c.contains("torch"))
            return one("action" to "flashlight", "on" to !c.contains("off"))
        if (c == "go back" || c == "back") return one("action" to "global", "which" to "back")
        if (c == "go home" || c == "home") return one("action" to "global", "which" to "home")
        if (c.contains("volume up")) return one("action" to "volume", "dir" to "up", "steps" to 2)
        if (c.contains("volume down")) return one("action" to "volume", "dir" to "down", "steps" to 2)

        if (c.startsWith("scroll") || c.startsWith("swipe")) {
            val dir = when {
                c.contains("up") -> "up"
                c.contains("left") -> "left"
                c.contains("right") -> "right"
                else -> "down"
            }
            return one("action" to "scroll", "dir" to dir)
        }
        if (c in setOf("next", "next reel", "next video", "next post", "next one")) return one("action" to "scroll", "dir" to "down")
        if (c in setOf("previous", "previous reel", "previous video", "previous post", "previous one")) return one("action" to "scroll", "dir" to "up")
        if (c in setOf("like", "like this", "like it", "like the reel", "like this reel", "double tap"))
            return one("action" to "double_tap")
        return null
    }

    private fun post(model: String, key: String, body: JSONObject, readMs: Int = 20000): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.doOutput = true
        conn.connectTimeout = 10000
        conn.readTimeout = readMs
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return code to (stream?.bufferedReader()?.readText() ?: "")
    }

    private fun contextLine(ctx: Context, screen: String): String {
        val time = SimpleDateFormat("EEE d MMM yyyy, h:mm a", Locale.getDefault()).format(Date())
        return "Time: $time. Battery: " + battery(ctx) + "%. $screen"
    }

    /** One planning step. continued = true means "look at the new screen and carry on". */
    fun plan(ctx: Context, cmd: String, screen: String, continued: Boolean): Plan {
        val key = Prefs.key(ctx)
        if (key.isBlank()) return Plan(say("Please paste your Gemini API key in the Karen setup first."), false)

        val contents = JSONArray()
        for ((u, m) in history) { contents.put(msg("user", u)); contents.put(msg("model", m)) }
        val turn = if (continued)
            "[" + contextLine(ctx, screen) + "]\nContinue the task. Original command: " + cmd +
                ". Your earlier actions already ran. Look at the screen now and do the next step, or finish."
        else "[" + contextLine(ctx, screen) + "]\nCommand: " + cmd
        contents.put(msg("user", turn))

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val main = Prefs.model(ctx)
        val models = listOf(main) + FALLBACKS.filter { it != main }

        var lastCode = 0
        for (model in models) {
            val (code, resp) = try { post(model, key, body) } catch (e: Exception) { -1 to "" }
            lastCode = code
            if (code in 200..299) return parsePlan(cmd, resp, !continued)
            if (code == 503 || code == 429 || code == 500 || code == -1) Thread.sleep(500)
        }
        return Plan(
            if (lastCode == 400 || lastCode == 401 || lastCode == 403)
                say("The AI says your key was rejected. Check your Gemini key in the Karen setup.")
            else say("The AI is busy right now, error $lastCode. Please try again in a moment."),
            false
        )
    }

    private fun textOf(resp: String): String {
        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
        }
        return sb.toString()
    }

    private fun parsePlan(cmd: String, resp: String, store: Boolean): Plan {
        return try {
            val clean = textOf(resp).trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val plan = if (clean.startsWith("[")) Plan(JSONArray(clean), false) else {
                val o = JSONObject(clean)
                if (o.has("actions")) Plan(o.getJSONArray("actions"), o.optBoolean("more", false))
                else Plan(JSONArray().put(o), false)
            }
            if (store) {
                history.add(cmd to clean)
                if (history.size > 6) history.removeAt(0)
            }
            plan
        } catch (e: Exception) {
            Plan(say("Sorry, I didn't understand the AI's answer."), false)
        }
    }

    /** Asks the AI to write real code (or a one-file web app). Returns null if it can't. */
    fun codegen(ctx: Context, description: String, language: String): String? {
        val key = Prefs.key(ctx)
        if (key.isBlank()) return null
        val prompt = if (language == "html")
            "Create a complete single-file mobile web app as one self-contained HTML document: inline CSS and JavaScript only, " +
                "no external libraries, fonts or network requests, works offline, touch friendly, polished dark theme with red accents. " +
                "The app: $description. Output ONLY the HTML, no explanation, no markdown fences."
        else "Write complete, working $language code for: $description. Output ONLY the code, no explanation, no markdown fences."
        val body = JSONObject()
            .put("contents", JSONArray().put(msg("user", prompt)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 8192))
        val main = Prefs.model(ctx)
        for (model in listOf(main) + FALLBACKS.filter { it != main }) {
            val (code, resp) = try { post(model, key, body, 90000) } catch (e: Exception) { -1 to "" }
            if (code in 200..299) {
                return try {
                    var t = textOf(resp).trim()
                    if (t.startsWith("```")) t = t.substringAfter('\n')
                    t.removeSuffix("```").trim()
                } catch (e: Exception) { null }
            }
            if (code == 503 || code == 429 || code == 500 || code == -1) Thread.sleep(500)
        }
        return null
    }
}
