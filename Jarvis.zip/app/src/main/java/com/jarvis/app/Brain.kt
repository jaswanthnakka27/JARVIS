package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    private val history = ArrayList<Pair<String, String>>()
    // Tried in order if the main model is busy (503) or missing (404)
    private val FALLBACKS = listOf("gemini-3.7-flash", "gemini-3.5-flash")

    private const val SYSTEM = """You are Jarvis, a voice assistant that controls an Android phone.
The user speaks a command. Reply with ONLY a JSON array of actions, run in order.
Actions:
{"action":"speak","text":"..."}  say something out loud (short, spoken style, same language as the user)
{"action":"open_app","target":"app name"}
{"action":"search","query":"..."}  google search
{"action":"open_url","url":"https://..."}
{"action":"call","target":"contact name or phone number"}
{"action":"global","which":"home|back|recents|notifications|quick_settings|lock|screenshot"}
{"action":"click","text":"visible text on screen to tap"}
{"action":"type","text":"text to type into the focused field"}
{"action":"scroll","dir":"up|down|left|right"}  down = reveal content below
{"action":"flashlight","on":true}
{"action":"volume","dir":"up|down|mute|unmute","steps":2}
{"action":"alarm","hour":7,"minute":30}
{"action":"wait","ms":1500}  use after open_app before click or type
Rules: for questions or chat, just use speak with the answer. For phone tasks, finish with a short speak confirmation. Never invent actions. Output valid JSON only."""

    private fun speak(t: String) =
        JSONArray().put(JSONObject().put("action", "speak").put("text", t))

    private fun act(vararg kv: Pair<String, Any>): JSONObject {
        val o = JSONObject()
        for ((k, v) in kv) o.put(k, v)
        return o
    }

    private fun msg(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    /** Simple commands are handled instantly on the phone, with no internet or AI needed. */
    private fun local(cmd: String): JSONArray? {
        val c = cmd.lowercase().trim().trimEnd('.', '!', '?')

        Regex("^(?:please )?(?:open|launch|start) (?:the )?(.+?)(?: app)?$").find(c)?.let {
            val target = it.groupValues[1]
            if (!target.contains(" and ") && !target.contains(" then "))
                return JSONArray().put(act("action" to "open_app", "target" to target))
        }
        if (c.contains("flashlight") || c.contains("torch"))
            return JSONArray().put(act("action" to "flashlight", "on" to !c.contains("off")))
        if (c == "go back" || c == "back")
            return JSONArray().put(act("action" to "global", "which" to "back"))
        if (c == "go home" || c == "home")
            return JSONArray().put(act("action" to "global", "which" to "home"))
        if (c.contains("volume up")) return JSONArray().put(act("action" to "volume", "dir" to "up", "steps" to 2))
        if (c.contains("volume down")) return JSONArray().put(act("action" to "volume", "dir" to "down", "steps" to 2))
        if (c == "scroll down") return JSONArray().put(act("action" to "scroll", "dir" to "down"))
        if (c == "scroll up") return JSONArray().put(act("action" to "scroll", "dir" to "up"))
        return null
    }

    fun ask(ctx: Context, cmd: String): JSONArray = local(cmd) ?: askAI(ctx, cmd)

    private fun post(model: String, key: String, body: JSONObject): Pair<Int, String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return code to (stream?.bufferedReader()?.readText() ?: "")
    }

    private fun askAI(ctx: Context, cmd: String): JSONArray {
        val key = Prefs.key(ctx)
        if (key.isBlank()) return speak("Please paste your Gemini API key in the Jarvis app first.")

        val contents = JSONArray()
        for ((u, m) in history) { contents.put(msg("user", u)); contents.put(msg("model", m)) }
        contents.put(msg("user", cmd))

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val main = Prefs.model(ctx)
        val models = listOf(main) + FALLBACKS.filter { it != main }

        var lastCode = 0
        for (model in models) {
            for (attempt in 1..2) {
                val (code, resp) = try { post(model, key, body) } catch (e: Exception) { -1 to "" }
                lastCode = code
                if (code in 200..299) return parse(cmd, resp)
                if (code == 503 || code == 429 || code == 500 || code == -1) { Thread.sleep(1200); continue }
                break // 400 / 403 / 404: try the next model
            }
        }
        return if (lastCode == 400 || lastCode == 401 || lastCode == 403)
            speak("The AI says your key was rejected. Check your Gemini key in the Jarvis app.")
        else speak("The AI is busy right now, error $lastCode. Please try again in a moment.")
    }

    private fun parse(cmd: String, resp: String): JSONArray {
        return try {
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
            }
            val clean = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val actions = if (clean.startsWith("[")) JSONArray(clean) else JSONArray().put(JSONObject(clean))
            history.add(cmd to clean)
            if (history.size > 6) history.removeAt(0)
            actions
        } catch (e: Exception) {
            speak("Sorry, I didn't understand the AI's answer.")
        }
    }
}
