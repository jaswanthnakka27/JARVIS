package com.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    private val history = ArrayList<Pair<String, String>>()

    private const val SYSTEM = """You are Jarvis, a voice assistant that controls an Android phone.
The user speaks a command. Reply with ONLY a JSON array of actions, run in order.
Actions:
{"action":"speak","text":"..."}  say something out loud (short, spoken style, same language as the user)
{"action":"open_app","target":"app name"}
{"action":"search","query":"..."}  google search
{"action":"open_url","url":"https://..."}
{"action":"call","target":"contact name or phone number"}
{"action":"global","which":"home|back|recents|notifications|quick_settings|lock|screenshot"}
{"action":"click","text":"visible text on screen to tap"}
{"action":"type","text":"text to type into the focused field"}
{"action":"scroll","dir":"up|down|left|right"}  down = reveal content below
{"action":"flashlight","on":true}
{"action":"volume","dir":"up|down|mute|unmute","steps":2}
{"action":"alarm","hour":7,"minute":30}
{"action":"wait","ms":1500}  use after open_app before click or type
Rules: for questions or chat, just use speak with the answer. For phone tasks, finish with a short speak confirmation. Never invent actions. Output valid JSON only."""

    private fun speak(t: String) =
        JSONArray().put(JSONObject().put("action", "speak").put("text", t))

    private fun msg(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun ask(ctx: Context, cmd: String): JSONArray {
        val key = Prefs.key(ctx)
        if (key.isBlank()) return speak("Please paste your Gemini API key in the Jarvis app first.")

        val contents = JSONArray()
        for ((u, m) in history) { contents.put(msg("user", u)); contents.put(msg("model", m)) }
        contents.put(msg("user", cmd))

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val model = Prefs.model(ctx)
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream.bufferedReader().readText()
        if (code !in 200..299) return speak("The AI returned error $code for model $model. Check the model name in the Jarvis app.")

        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
        }
        val text = sb.toString()
        val clean = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val actions = if (clean.startsWith("[")) JSONArray(clean) else JSONArray().put(JSONObject(clean))

        history.add(cmd to clean)
        if (history.size > 6) history.removeAt(0)
        return actions
    }
}
