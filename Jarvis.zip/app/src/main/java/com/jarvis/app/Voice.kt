package com.jarvis.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale

/** Karen's voice: a natural Gemini AI voice, with the phone's own voice as backup. */
class Voice(private val ctx: Context, private val finished: () -> Unit) : TextToSpeech.OnInitListener {

    companion object {
        private val TTS_MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
        @Volatile private var skipUntil = 0L
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(ctx, this)
    private var ready = false
    private var track: AudioTrack? = null
    @Volatile private var cancelled = false

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        val t = tts ?: return
        t.language = Locale.getDefault()
        t.setPitch(1.1f)
        t.setSpeechRate(1.02f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { finished() } }
            override fun onError(id: String?) { main.post { finished() } }
        })
    }

    private fun cacheFile(text: String): File {
        val raw = Prefs.voiceName(ctx) + "|" + text
        val h = MessageDigest.getInstance("MD5").digest(raw.toByteArray()).joinToString("") { "%02x".format(it) }
        return File(File(ctx.cacheDir, "tts"), "$h.pcm")
    }

    private fun save(f: File, pcm: ByteArray) {
        try { f.parentFile?.mkdirs(); f.writeBytes(pcm) } catch (e: Exception) { }
    }

    /** Pre-make the short phrases Karen says most, so they play instantly. */
    fun prewarm(texts: List<String>) {
        if (!Prefs.aiVoice(ctx) || Prefs.key(ctx).isBlank()) return
        Thread {
            for (t in texts) {
                val f = cacheFile(t)
                if (f.exists()) continue
                try { fetch(t)?.let { save(f, it) } } catch (e: Exception) { }
            }
        }.start()
    }

    fun speak(text: String) {
        cancelled = false
        val useAi = Prefs.aiVoice(ctx) && Prefs.key(ctx).isNotBlank() && text.length < 320
        if (!useAi) { fallback(text); return }
        Thread {
            val f = cacheFile(text)
            var pcm: ByteArray? = if (f.exists()) f.readBytes() else null
            if (pcm == null && System.currentTimeMillis() > skipUntil) {
                pcm = try { fetch(text) } catch (e: Exception) { null }
                if (pcm != null) save(f, pcm) else skipUntil = System.currentTimeMillis() + 60_000
            }
            if (cancelled) return@Thread
            if (pcm == null) main.post { fallback(text) } else play(pcm)
        }.start()
    }

    private fun fallback(text: String) {
        if (!ready) { finished(); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "karen")
    }

    private fun fetch(text: String): ByteArray? {
        val key = Prefs.key(ctx)
        val voiceCfg = JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", Prefs.voiceName(ctx)))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject()
                .put("text", "Say in a calm, crisp, intelligent female AI assistant voice, slightly witty and confident, like a high-tech suit assistant: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", voiceCfg)))
        for (model in TTS_MODELS) {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.doOutput = true
            conn.connectTimeout = 8000
            conn.readTimeout = 15000
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode !in 200..299) continue
            val resp = conn.inputStream.bufferedReader().readText()
            val b64 = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getJSONObject("inlineData").getString("data")
            return Base64.decode(b64, Base64.DEFAULT)
        }
        return null
    }

    private fun play(pcm: ByteArray) {
        val rate = 24000
        val minBuf = AudioTrack.getMinBufferSize(rate, android.media.AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        try {
            t.play()
            t.write(pcm, 0, pcm.size)
            val frames = pcm.size / 2
            var guard = 0
            while (!cancelled && t.playbackHeadPosition < frames && guard < 1200) {
                Thread.sleep(50); guard++
            }
            t.stop()
        } catch (e: Exception) {
        } finally {
            try { t.release() } catch (e: Exception) {}
            track = null
        }
        if (!cancelled) main.post { finished() }
    }

    fun stop() {
        cancelled = true
        try { track?.pause(); track?.flush() } catch (e: Exception) {}
        tts?.stop()
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
    }
}
