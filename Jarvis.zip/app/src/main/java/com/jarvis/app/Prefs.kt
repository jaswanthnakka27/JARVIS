package com.jarvis.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun key(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun save(c: Context, k: String) = sp(c).edit().putString("api_key", k).apply()
}
