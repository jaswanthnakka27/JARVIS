package com.jarvis.app

import android.content.Context

object Prefs {
    const val DEFAULT_MODEL = "gemini-3.8-flash"
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun key(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun model(c: Context): String =
        (sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }
    fun save(c: Context, k: String, m: String) =
        sp(c).edit().putString("api_key", k).putString("model", m).apply()
}
