package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Animated Spider-Man x Iron Man HUD: living web, arc-reactor core, spider emblem, voice waves. */
class HudView(ctx: Context) : View(ctx) {

    var mode = 0                      // 0 idle, 1 listening, 2 thinking, 3 speaking
    var onCenterTap: (() -> Unit)? = null

    private val red = Color.parseColor("#FF1E2D")
    private val dark = Color.parseColor("#06060A")
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mono = Typeface.create("monospace", Typeface.BOLD)
    private val path = Path()
    private val oval = RectF()
    private var last = System.nanoTime()
    private var t = 0f
    private var spin = 0f
    private var amp = 0.25f
    private var cx = 0f
    private var cy = 0f
    private var rad = 0f
    private val twoPi = (2.0 * Math.PI).toFloat()
    private val dust = Array(46) {
        floatArrayOf(Math.random().toFloat(), Math.random().toFloat(), 0.3f + Math.random().toFloat())
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = min(0.05f, (now - last) / 1e9f)
        last = now
        t += dt
        val target = when (mode) { 1 -> 1.0f; 2 -> 0.65f; 3 -> 0.9f; else -> 0.25f }
        amp += (target - amp) * min(1f, dt * 4f)
        spin += dt * (20f + amp * 170f)

        val w = width.toFloat()
        val h = height.toFloat()
        cx = w / 2
        cy = h * 0.40f
        rad = min(w, h) * 0.27f

        c.drawColor(dark)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, rad * 3.4f,
            intArrayOf(Color.argb((60 + 55 * amp).toInt(), 255, 20, 40), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        drawWeb(c, w, h)
        drawDust(c, w, h, dt)
        drawReactor(c)
        drawCorners(c, w, h)
        postInvalidateOnAnimation()
    }

    private fun drawWeb(c: Canvas, w: Float, h: Float) {
        val spokes = 16
        val far = hypot(w, h)
        val rot = t * 0.03f
        val step = twoPi / spokes
        p.style = Paint.Style.STROKE
        p.strokeWidth = d * 0.8f
        p.color = Color.argb(46, 255, 30, 50)
        for (i in 0 until spokes) {
            val a = rot + i * step
            c.drawLine(cx + cos(a) * rad * 0.6f, cy + sin(a) * rad * 0.6f, cx + cos(a) * far, cy + sin(a) * far, p)
        }
        p.color = Color.argb(38, 255, 30, 50)
        for (k in 1..10) {
            val r = rad * (0.75f + k * 0.42f) + sin(t * 0.8f + k) * d * 2f
            path.reset()
            for (i in 0..spokes) {
                val a = rot + i * step
                val x = cx + cos(a) * r
                val y = cy + sin(a) * r
                if (i == 0) path.moveTo(x, y) else {
                    val am = a - step / 2f
                    val sag = r * 0.93f
                    path.quadTo(cx + cos(am) * sag, cy + sin(am) * sag, x, y)
                }
            }
            c.drawPath(path, p)
        }
    }

    private fun drawDust(c: Canvas, w: Float, h: Float, dt: Float) {
        p.style = Paint.Style.FILL
        for (s in dust) {
            s[1] -= dt * 0.02f * s[2]
            if (s[1] < 0f) s[1] += 1f
            p.color = Color.argb((90 * s[2]).toInt().coerceAtMost(255), 255, 60, 70)
            c.drawCircle(s[0] * w, s[1] * h, d * (0.6f + s[2] * 1.2f), p)
        }
    }

    private fun drawReactor(c: Canvas) {
        val pulse = 1f + 0.05f * sin(t * (2f + amp * 6f))

        // outer ring and tick marks
        p.style = Paint.Style.STROKE
        p.strokeWidth = d * 2.5f
        p.color = red
        c.drawCircle(cx, cy, rad, p)
        p.strokeWidth = d * 1.2f
        p.color = Color.argb(200, 255, 30, 50)
        for (i in 0 until 72) {
            val a = Math.toRadians((i * 5 + spin * 0.2f).toDouble()).toFloat()
            val r0 = rad * (if (i % 6 == 0) 0.9f else 0.94f)
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * rad * 0.99f, cy + sin(a) * rad * 0.99f, p)
        }

        // rotating arc segments
        p.strokeCap = Paint.Cap.ROUND
        oval.set(cx - rad * 0.8f, cy - rad * 0.8f, cx + rad * 0.8f, cy + rad * 0.8f)
        p.strokeWidth = d * 9f
        p.color = Color.argb(230, 255, 30, 50)
        for (i in 0 until 3) c.drawArc(oval, spin + i * 120f, 78f, false, p)
        oval.set(cx - rad * 0.64f, cy - rad * 0.64f, cx + rad * 0.64f, cy + rad * 0.64f)
        p.strokeWidth = d * 5f
        p.color = Color.argb(180, 255, 120, 130)
        for (i in 0 until 2) c.drawArc(oval, -spin * 1.4f + i * 180f, 100f, false, p)
        p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = d * 1.5f
        p.color = Color.argb(160, 255, 30, 50)
        c.drawCircle(cx, cy, rad * 0.52f, p)

        // glowing core
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, rad * 0.5f * pulse,
            intArrayOf(Color.parseColor("#FFB4B8"), Color.parseColor("#FF2A3A"), Color.parseColor("#8A0012")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rad * 0.5f * pulse, p)
        p.shader = null
        spider(c, cx, cy + rad * 0.02f, rad * 0.62f, Color.parseColor("#07070B"))

        // voice waves around the reactor
        val n = 56
        p.style = Paint.Style.STROKE
        p.strokeWidth = d * 3f
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until n) {
            val a = i * twoPi / n
            val v = when (mode) {
                1, 3 -> 0.3f + 0.7f * abs(sin(t * 5f + i * 0.9f) * sin(t * 2.3f + i * 0.3f))
                2 -> if ((i + (t * 14f).toInt()) % n < 8) 1f else 0.12f
                else -> 0.12f + 0.08f * sin(t + i)
            }
            val r0 = rad * 1.06f
            val r1 = r0 + v * rad * 0.2f
            p.color = Color.argb((110 + 140 * v).toInt().coerceAtMost(255), 255, 40, 55)
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * r1, cy + sin(a) * r1, p)
        }
        p.strokeCap = Paint.Cap.BUTT

        // text running around the reactor
        p.style = Paint.Style.FILL
        p.typeface = mono
        p.textSize = d * 11f
        p.color = Color.argb(200, 255, 90, 100)
        val tr = rad * 1.36f
        path.reset()
        path.addCircle(cx, cy, tr, Path.Direction.CW)
        val label = "K.A.R.E.N  \u25C8  ONLINE  \u25C8  NEURAL LINK ACTIVE  \u2726  FRIENDLY NEIGHBORHOOD AI  \u25C8  "
        val circ = twoPi * tr
        c.drawTextOnPath(label, path, t * 30f, 0f, p)
        c.drawTextOnPath(label, path, t * 30f + circ / 2f, 0f, p)
        p.typeface = null
    }

    private fun spider(c: Canvas, x: Float, y: Float, s: Float, col: Int) {
        p.color = col
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.06f
        val legs = arrayOf(
            floatArrayOf(0.10f, -0.16f, 0.36f, -0.34f, 0.52f, -0.50f),
            floatArrayOf(0.11f, -0.04f, 0.42f, -0.12f, 0.58f, -0.20f),
            floatArrayOf(0.11f, 0.06f, 0.42f, 0.14f, 0.58f, 0.26f),
            floatArrayOf(0.10f, 0.16f, 0.34f, 0.36f, 0.48f, 0.54f)
        )
        for (sx in floatArrayOf(-1f, 1f)) {
            for (l in legs) {
                path.reset()
                path.moveTo(x + sx * l[0] * s, y + l[1] * s)
                path.lineTo(x + sx * l[2] * s, y + l[3] * s)
                path.lineTo(x + sx * l[4] * s, y + l[5] * s)
                c.drawPath(path, p)
            }
        }
        p.style = Paint.Style.FILL
        c.drawOval(x - 0.13f * s, y - 0.04f * s, x + 0.13f * s, y + 0.30f * s, p)
        c.drawCircle(x, y - 0.14f * s, 0.085f * s, p)
        p.strokeCap = Paint.Cap.BUTT
    }

    private fun drawCorners(c: Canvas, w: Float, h: Float) {
        val m = d * 18f
        val l = d * 26f
        p.style = Paint.Style.STROKE
        p.strokeWidth = d * 2f
        p.color = Color.argb(200, 255, 30, 50)
        c.drawLine(m, m, m + l, m, p); c.drawLine(m, m, m, m + l, p)
        c.drawLine(w - m, m, w - m - l, m, p); c.drawLine(w - m, m, w - m, m + l, p)
        c.drawLine(m, h - m, m + l, h - m, p); c.drawLine(m, h - m, m, h - m - l, p)
        c.drawLine(w - m, h - m, w - m - l, h - m, p); c.drawLine(w - m, h - m, w - m, h - m - l, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP && hypot(e.x - cx, e.y - cy) < rad * 1.1f) {
            onCenterTap?.invoke()
        }
        return true
    }
}
