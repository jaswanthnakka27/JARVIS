package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var hud: HudView
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var panel: ScrollView
    private lateinit var power: Button
    private lateinit var voiceBtn: Button
    private val red = Color.parseColor("#FF1E2D")
    private var dens = 1f

    private fun dp(v: Int) = (v * dens).toInt()

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = true
        setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        textSize = 14f
        letterSpacing = 0.12f
        background = GradientDrawable().apply {
            setColor(Color.argb(46, 255, 30, 50))
            setStroke(dp(1), red)
            cornerRadius = dp(14).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        setSingleLine()
        setTextColor(Color.WHITE)
        setHintTextColor(Color.argb(120, 255, 255, 255))
        typeface = Typeface.MONOSPACE
        textSize = 13f
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            setColor(Color.argb(30, 255, 255, 255))
            setStroke(dp(1), Color.argb(160, 255, 30, 50))
            cornerRadius = dp(10).toFloat()
        }
    }

    private fun label(t: String, size: Float, face: Typeface, color: Int): TextView = TextView(this).apply {
        text = t
        textSize = size
        typeface = face
        setTextColor(color)
        gravity = Gravity.CENTER
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dens = resources.displayMetrics.density
        window.statusBarColor = Color.parseColor("#06060A")
        window.navigationBarColor = Color.parseColor("#06060A")

        val root = FrameLayout(this)
        hud = HudView(this).apply { onCenterTap = { talk() } }
        root.addView(hud, FrameLayout.LayoutParams(-1, -1))

        // ---- main screen ----
        val ui = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(28))
        }
        val title = label("K\u00B7A\u00B7R\u00B7E\u00B7N", 36f, Typeface.create("sans-serif-black", Typeface.NORMAL), red)
        title.letterSpacing = 0.25f
        title.setShadowLayer(26f, 0f, 0f, red)
        ui.addView(title)
        ui.addView(label("\u2726  YOUR FRIENDLY NEIGHBORHOOD AI  \u2726", 11f,
            Typeface.create("serif", Typeface.ITALIC), Color.argb(190, 255, 140, 150)))
        ui.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))

        status = label("", 15f, Typeface.MONOSPACE, Color.WHITE)
        status.minLines = 2
        status.maxLines = 6
        status.setPadding(0, 0, 0, dp(6))
        ui.addView(status)
        info = label("", 11f, Typeface.MONOSPACE, Color.argb(220, 255, 70, 85))
        ui.addView(info)

        fun lp() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(4), dp(12), dp(4), 0)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("\u25C9 Talk") { talk() }, lp())
        row.addView(button("\u2699 Setup") { panel.visibility = View.VISIBLE }, lp())
        power = button("\u25B6 Start") { togglePower() }
        row.addView(power, lp())
        ui.addView(row)
        root.addView(ui, FrameLayout.LayoutParams(-1, -1))

        // ---- setup panel ----
        panel = ScrollView(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.argb(244, 6, 6, 10))
        }
        val pc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(28))
        }
        panel.addView(pc)
        pc.addView(label("\u2699  SETUP", 24f, Typeface.create("sans-serif-black", Typeface.NORMAL), red))

        val key = field("Gemini API key (free at aistudio.google.com)", Prefs.key(this))
        val model = field("AI model name", Prefs.model(this))
        pc.addView(key, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(16), 0, 0) })
        pc.addView(model, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, 0) })

        fun add(b: Button) = pc.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, 0) })
        add(button("Save key and model") {
            Prefs.save(this, key.text.toString().trim(), model.text.toString().trim())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        voiceBtn = button("") {
            Prefs.setAiVoice(this, !Prefs.aiVoice(this))
            refresh()
        }
        add(voiceBtn)
        add(button("1. Grant permissions") {
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.ANSWER_PHONE_CALLS
                ), 1
            )
        })
        add(button("2. Enable accessibility (Karen Control)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        add(button("3. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        add(button("4. Disable battery optimization") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        add(button("\u2715 Close") { panel.visibility = View.GONE })
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
    }

    private fun talk() {
        if (!JarvisService.running) {
            Toast.makeText(this, "Tap Start first", Toast.LENGTH_SHORT).show()
            return
        }
        startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_TALK))
    }

    private fun togglePower() {
        if (JarvisService.running) {
            stopService(Intent(this, JarvisService::class.java))
        } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Open Setup and grant permissions first", Toast.LENGTH_LONG).show()
            return
        } else {
            startForegroundService(Intent(this, JarvisService::class.java))
        }
        status.postDelayed({ refresh() }, 500)
    }

    override fun onResume() {
        super.onResume()
        JarvisService.onState = { runOnUiThread { refresh() } }
        JarvisService.onHide = { runOnUiThread { moveTaskToBack(true) } }
        refresh()
    }

    override fun onPause() {
        JarvisService.onState = null
        JarvisService.onHide = null
        super.onPause()
    }

    private fun refresh() {
        hud.mode = JarvisService.mode
        status.text = JarvisService.state.ifBlank { "OFFLINE. Tap Start" }
        info.text = "CORE " + (if (JarvisService.running) "ON" else "OFF") + "   \u25C8   CONTROL " +
            (if (JarvisAccessibility.instance != null) "ON" else "OFF")
        power.text = if (JarvisService.running) "\u25A0 Stop" else "\u25B6 Start"
        voiceBtn.text = "AI voice: " + (if (Prefs.aiVoice(this)) "ON" else "OFF")
    }
}
