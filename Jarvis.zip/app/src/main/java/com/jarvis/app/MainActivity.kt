package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun add(v: View) = col.addView(v)
        fun btn(label: String, onClick: () -> Unit) {
            add(Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { onClick() }
            })
        }

        add(TextView(this).apply { text = "Jarvis"; textSize = 30f })
        status = TextView(this).apply { textSize = 18f; setPadding(0, pad / 2, 0, pad) }
        add(status)

        val key = EditText(this).apply {
            hint = "Gemini API key (free at aistudio.google.com)"
            setText(Prefs.key(this@MainActivity))
            setSingleLine()
        }
        add(key)
        val model = EditText(this).apply {
            hint = "AI model name"
            setText(Prefs.model(this@MainActivity))
            setSingleLine()
        }
        add(model)
        btn("Save key and model") {
            Prefs.save(this, key.text.toString().trim(), model.text.toString().trim())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        btn("1. Grant permissions") {
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_CONTACTS
                ), 1
            )
        }
        btn("2. Enable accessibility (Jarvis Control)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("4. Disable battery optimization") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        btn("Start Jarvis") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Grant permissions first", Toast.LENGTH_SHORT).show()
            } else {
                startForegroundService(Intent(this, JarvisService::class.java))
                status.postDelayed({ refresh() }, 500)
            }
        }
        btn("Talk now") {
            if (JarvisService.running) {
                startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_TALK))
            } else {
                Toast.makeText(this, "Tap Start Jarvis first", Toast.LENGTH_SHORT).show()
            }
        }
        btn("Stop Jarvis") {
            stopService(Intent(this, JarvisService::class.java))
            status.postDelayed({ refresh() }, 500)
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        JarvisService.onState = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() {
        JarvisService.onState = null
        super.onPause()
    }

    private fun refresh() {
        status.text = "Listening service: " + (if (JarvisService.running) "ON" else "OFF") +
            "\nPhone control: " + (if (JarvisAccessibility.instance != null) "ON" else "OFF") +
            "\n\n" + JarvisService.state
    }
}
