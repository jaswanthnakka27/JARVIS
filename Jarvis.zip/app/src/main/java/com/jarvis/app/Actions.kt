package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject

object Actions {
    private const val NEED_ACC = "Please enable my accessibility service first. "

    /** Runs all actions, returns the text Jarvis should say out loud. */
    fun run(ctx: Context, actions: JSONArray): String {
        val say = StringBuilder()
        for (i in 0 until actions.length()) {
            val a = actions.optJSONObject(i) ?: continue
            try { exec(ctx, a, say) } catch (e: Exception) { say.append("I couldn't do that. ") }
        }
        return say.toString().trim()
    }

    // Starting activities from the accessibility service avoids background-launch blocks
    private fun ui(ctx: Context): Context = JarvisAccessibility.instance ?: ctx

    private fun exec(ctx: Context, a: JSONObject, say: StringBuilder) {
        when (a.optString("action")) {
            "speak" -> say.append(a.optString("text")).append(' ')
            "open_app" -> if (!openApp(ctx, a.optString("target"))) say.append("I can't find ${a.optString("target")}. ")
            "search" -> view(ctx, "https://www.google.com/search?q=" + Uri.encode(a.optString("query")))
            "open_url" -> view(ctx, a.optString("url"))
            "call" -> call(ctx, a.optString("target"), say)
            "global" -> global(a.optString("which"), say)
            "click" -> {
                val acc = JarvisAccessibility.instance
                if (acc == null) say.append(NEED_ACC)
                else if (!acc.clickText(a.optString("text"))) say.append("I couldn't find ${a.optString("text")} on the screen. ")
            }
            "type" -> {
                val acc = JarvisAccessibility.instance
                if (acc == null) say.append(NEED_ACC)
                else if (!acc.typeText(a.optString("text"))) say.append("There's no text box selected. ")
            }
            "scroll" -> JarvisAccessibility.instance?.swipe(a.optString("dir")) ?: say.append(NEED_ACC)
            "flashlight" -> torch(ctx, a.optBoolean("on", true))
            "volume" -> volume(ctx, a.optString("dir"), a.optInt("steps", 2))
            "alarm" -> alarm(ctx, a.optInt("hour"), a.optInt("minute"))
            "wait" -> Thread.sleep(a.optLong("ms", 800).coerceIn(0, 5000))
            else -> say.append("I don't know that action. ")
        }
    }

    private fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val q = name.lowercase().trim()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return false
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ui(ctx).startActivity(i)
        return true
    }

    private fun view(ctx: Context, url: String) {
        ui(ctx).startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun call(ctx: Context, target: String, say: StringBuilder) {
        val number = if (target.any { it.isDigit() }) target.filter { it.isDigit() || it == '+' }
        else findContact(ctx, target)
        if (number == null) { say.append("I couldn't find $target in your contacts. "); return }
        ui(ctx).startActivity(
            Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun findContact(ctx: Context, name: String): String? {
        val P = ContactsContract.CommonDataKinds.Phone
        ctx.contentResolver.query(
            P.CONTENT_URI, arrayOf(P.NUMBER), "${P.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun global(which: String, say: StringBuilder) {
        val acc = JarvisAccessibility.instance
        if (acc == null) { say.append(NEED_ACC); return }
        val code = when (which) {
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
            "screenshot" -> AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
            else -> return
        }
        acc.performGlobalAction(code)
    }

    private fun torch(ctx: Context, on: Boolean) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    }

    private fun volume(ctx: Context, dir: String, steps: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val d = when (dir) {
            "up" -> AudioManager.ADJUST_RAISE
            "down" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_MUTE
            else -> AudioManager.ADJUST_UNMUTE
        }
        repeat(steps.coerceIn(1, 10)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI) }
    }

    private fun alarm(ctx: Context, h: Int, m: Int) {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ui(ctx).startActivity(i)
    }
}
