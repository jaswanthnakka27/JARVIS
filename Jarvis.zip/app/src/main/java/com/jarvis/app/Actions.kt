package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.telecom.TelecomManager
import org.json.JSONArray
import org.json.JSONObject

object Actions {
    private const val NEED_ACC = "Please enable my accessibility service first. "

    /** Set when Karen asked "what should I say?" and is waiting for the message text. */
    @Volatile var pendingContact: String? = null

    private val NO_SCREEN = setOf("speak", "wait", "flashlight", "volume", "alarm", "timer", "answer_call", "end_call")
    private val LOCK_SAFE = setOf("speak", "wait", "flashlight", "volume", "alarm", "timer", "answer_call",
        "end_call", "wake_screen", "unlock_swipe", "call")

    fun needsScreen(actions: JSONArray): Boolean {
        for (i in 0 until actions.length()) {
            val a = actions.optJSONObject(i) ?: continue
            val n = a.optString("action")
            if (n in NO_SCREEN) continue
            if (n == "whatsapp" && a.optString("text").isBlank()) continue
            return true
        }
        return false
    }

    fun lockedBlocks(ctx: Context, actions: JSONArray): Boolean {
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) return false
        for (i in 0 until actions.length()) {
            val a = actions.optJSONObject(i) ?: continue
            if (a.optString("action") !in LOCK_SAFE) return true
        }
        return false
    }

    /** Runs all actions, returns the text Karen should say out loud. */
    fun run(ctx: Context, actions: JSONArray): String {
        val say = StringBuilder()
        for (i in 0 until actions.length()) {
            val a = actions.optJSONObject(i) ?: continue
            try { exec(ctx, a, say) } catch (e: Exception) { say.append("I couldn't do that. ") }
        }
        return say.toString().trim()
    }

    // Starting activities from the accessibility service avoids background-launch blocks
    private fun ui(ctx: Context): Context = JarvisAccessibility.instance ?: ctx

    private fun exec(ctx: Context, a: JSONObject, say: StringBuilder) {
        val acc = JarvisAccessibility.instance
        when (a.optString("action")) {
            "speak" -> say.append(a.optString("text")).append(' ')
            "open_app" -> if (!openApp(ctx, a.optString("target"))) say.append("I can't find ${a.optString("target")}. ")
            "search" -> view(ctx, "https://www.google.com/search?q=" + Uri.encode(a.optString("query")))
            "youtube" -> view(ctx, "https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query")))
            "open_url" -> view(ctx, a.optString("url"))
            "navigate" -> navigate(ctx, a.optString("destination"))
            "call" -> call(ctx, a.optString("target"), say)
            "whatsapp" -> whatsapp(ctx, a.optString("contact"), a.optString("text"), say)
            "instagram" -> instagram(ctx, a.optString("section"), say)
            "global" -> global(a.optString("which"), say)
            "click" -> {
                if (acc == null) say.append(NEED_ACC)
                else if (!acc.clickText(a.optString("text"))) say.append("I couldn't find ${a.optString("text")} on the screen. ")
            }
            "type" -> {
                if (acc == null) say.append(NEED_ACC)
                else if (!acc.typeAnywhere(a.optString("text"))) say.append("I couldn't find a text box. ")
            }
            "scroll" -> if (acc == null) say.append(NEED_ACC) else acc.swipe(a.optString("dir"))
            "tap" -> if (acc == null) say.append(NEED_ACC)
                else acc.tap(a.optDouble("x", 0.5).toFloat(), a.optDouble("y", 0.5).toFloat(), false)
            "double_tap" -> if (acc == null) say.append(NEED_ACC) else acc.tap(0.5f, 0.5f, true)
            "flashlight" -> torch(ctx, a.optBoolean("on", true))
            "volume" -> volume(ctx, a.optString("dir"), a.optInt("steps", 2))
            "alarm" -> alarm(ctx, a.optInt("hour"), a.optInt("minute"))
            "timer" -> timer(ctx, a.optInt("seconds", 60))
            "settings" -> settings(ctx, a.optString("which"))
            "answer_call" -> answerCall(ctx, say)
            "end_call" -> endCall(ctx, say)
            "wake_screen" -> wake(ctx)
            "unlock_swipe" -> unlock(ctx, say)
            "wait" -> Thread.sleep(a.optLong("ms", 800).coerceIn(0, 5000))
            else -> say.append("I don't know that action. ")
        }
    }

    // ---------- apps & links ----------
    private fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val q = name.lowercase().trim()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return false
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ui(ctx).startActivity(i)
        return true
    }

    private fun view(ctx: Context, url: String) {
        ui(ctx).startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun navigate(ctx: Context, dest: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)))
                .setPackage("com.google.android.apps.maps").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ui(ctx).startActivity(i)
        } catch (e: Exception) {
            view(ctx, "https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(dest))
        }
    }

    private fun instagram(ctx: Context, section: String, say: StringBuilder) {
        val pm = ctx.packageManager
        val pkg = "com.instagram.android"
        val launch = pm.getLaunchIntentForPackage(pkg)
        if (launch == null) { say.append("Instagram isn't installed. "); return }
        val url = when (section) {
            "dms" -> "https://www.instagram.com/direct/inbox/"
            "reels" -> "https://www.instagram.com/reels/"
            "search" -> "https://www.instagram.com/explore/"
            else -> null
        }
        if (url != null) {
            try {
                ui(ctx).startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            } catch (e: Exception) { /* fall back to tapping */ }
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ui(ctx).startActivity(launch)
        val acc = JarvisAccessibility.instance ?: return
        Thread.sleep(2500)
        val labels = when (section) {
            "dms" -> listOf("Messenger", "Direct", "Messages")
            "reels" -> listOf("Reels")
            "search" -> listOf("Search and explore", "Search")
            else -> listOf("Home")
        }
        for (l in labels) if (acc.clickDesc(l)) return
    }

    // ---------- calls & WhatsApp ----------
    private fun call(ctx: Context, target: String, say: StringBuilder) {
        val number = if (target.any { it.isDigit() }) target.filter { it.isDigit() || it == '+' }
        else findContact(ctx, target)
        if (number == null) { say.append("I couldn't find $target in your contacts. "); return }
        ui(ctx).startActivity(
            Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun findContact(ctx: Context, name: String): String? {
        ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.NUMBER), "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun findWhatsAppId(ctx: Context, name: String): Long? {
        ctx.contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data._ID),
            ContactsContract.Data.MIMETYPE + " = ? AND " + ContactsContract.Data.DISPLAY_NAME + " LIKE ?",
            arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.profile", "%$name%"),
            null
        )?.use { if (it.moveToFirst()) return it.getLong(0) }
        return null
    }

    private fun whatsapp(ctx: Context, contact: String, text: String, say: StringBuilder) {
        if (contact.isBlank()) { say.append("Who should I message? "); return }
        if (text.isBlank()) {
            pendingContact = contact
            say.append("What should I say to $contact? ")
            return
        }
        val pm = ctx.packageManager
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pm.getLaunchIntentForPackage(it) != null }
        if (pkg == null) { say.append("WhatsApp isn't installed. "); return }
        val id = findWhatsAppId(ctx, contact)
        if (id == null) { say.append("I couldn't find $contact on WhatsApp. "); return }
        val acc = JarvisAccessibility.instance
        if (acc == null) { say.append(NEED_ACC); return }

        ui(ctx).startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.contacts/data/$id"))
                .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        Thread.sleep(2800)
        var typed = false
        for (n in 1..4) {
            if (acc.typeAnywhere(text)) { typed = true; break }
            Thread.sleep(600)
        }
        if (!typed) { say.append("I opened the chat but couldn't type. "); return }
        Thread.sleep(600)
        var sent = false
        for (n in 1..5) {
            if (acc.clickDesc("Send")) { sent = true; break }
            Thread.sleep(500)
        }
        say.append(if (sent) "Sent to $contact. " else "I typed it but couldn't press send. ")
    }

    private fun answerCall(ctx: Context, say: StringBuilder) {
        if (ctx.checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            say.append("I need the phone calls permission first. "); return
        }
        (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
    }

    private fun endCall(ctx: Context, say: StringBuilder) {
        if (ctx.checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            say.append("I need the phone calls permission first. "); return
        }
        if (Build.VERSION.SDK_INT >= 28) (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
    }

    // ---------- screen, lock, system ----------
    @Suppress("DEPRECATION")
    fun wake(ctx: Context) {
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "karen:wake")
                .acquire(8000)
        } catch (e: Exception) { }
    }

    private fun unlock(ctx: Context, say: StringBuilder) {
        val acc = JarvisAccessibility.instance
        if (acc == null) { say.append(NEED_ACC); return }
        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) return
        acc.swipeUpUnlock()
        Thread.sleep(900)
        if (km.isKeyguardLocked)
            say.append("I swiped it open, but your phone needs your PIN or fingerprint. Android doesn't let me do that part. ")
    }

    private fun global(which: String, say: StringBuilder) {
        val acc = JarvisAccessibility.instance
        if (acc == null) { say.append(NEED_ACC); return }
        val code = when (which) {
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
            "screenshot" -> AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
            else -> return
        }
        acc.performGlobalAction(code)
    }

    private fun settings(ctx: Context, which: String) {
        val action = when (which) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        ui(ctx).startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun torch(ctx: Context, on: Boolean) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    }

    private fun volume(ctx: Context, dir: String, steps: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val d = when (dir) {
            "up" -> AudioManager.ADJUST_RAISE
            "down" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_MUTE
            else -> AudioManager.ADJUST_UNMUTE
        }
        repeat(steps.coerceIn(1, 10)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI) }
    }

    private fun alarm(ctx: Context, h: Int, m: Int) {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ui(ctx).startActivity(i)
    }

    private fun timer(ctx: Context, seconds: Int) {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ui(ctx).startActivity(i)
    }
}
