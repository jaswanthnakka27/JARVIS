package com.jarvis.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** A small glowing reactor that floats over any app while Karen is listening, without taking focus. */
class OverlayHud(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var hud: HudView? = null
    private var label: TextView? = null

    fun show() {
        if (root != null || !Settings.canDrawOverlays(ctx)) return
        val d = ctx.resources.displayMetrics.density
        val h = HudView(ctx).apply { compact = true }
        val t = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            textSize = 12f
            gravity = Gravity.CENTER
            maxLines = 3
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.argb(200, 6, 6, 10))
                setStroke((1 * d).toInt(), Color.argb(200, 255, 30, 50))
                cornerRadius = 18 * d
            }
        }
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(h, LinearLayout.LayoutParams((150 * d).toInt(), (150 * d).toInt()))
            addView(t, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val lp = WindowManager.LayoutParams(
            (300 * d).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = (70 * d).toInt()
        }
        try {
            wm.addView(r, lp)
            root = r; hud = h; label = t
        } catch (e: Exception) { }
    }

    fun update(mode: Int, text: String) {
        hud?.mode = mode
        label?.text = text.take(100)
    }

    fun hide() {
        root?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        root = null; hud = null; label = null
    }
}
